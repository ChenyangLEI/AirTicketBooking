<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Users</title>
  </head>
  <body>
    <h1>Users</h1>


    <ul>
      <?php foreach ($users as $user): ?>
        <li>
          <form action="" method="post">
            <div>
              <?php htmlout($user['name']); ?>
              <?php htmlout($user['accout']); ?>
              <?php htmlout($user['phone']); ?>
              <?php htmlout($user['userpassword']); ?>
              <?php htmlout($acc); ?>

            
              <input type="hidden" name="id" value="<?php
                  echo $user['id']; ?>">
              <input type="submit" name="action" value="编辑">
              <input type="submit" name="action" value="已购机票">
                            <input type="submit" name="action" value="我的订单">

             
            </div>
          </form>
        </li>
      <?php endforeach; ?>
    </ul>
    <p><a href="..">返回首页</a></p>
    <form action="tickets/" method="post">
            <div>
             
             <input type="hidden" name="accout" value="<?php
                  echo $_SESSION['accout']; ?>">
                            <input type="submit" name="action" value="航班查询">

             
            </div>
          </form>
        <?php include '../logout.inc.html.php'; ?>

  </body>
</html>
