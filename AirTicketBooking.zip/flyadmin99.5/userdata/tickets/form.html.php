<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php htmlout($pageTitle); ?></title>
    <style type="text/css">
    textarea {
      display: block;
      width: 100%;
    }
    </style>
  </head>
  <body>
    <h1><?php htmlout($pageTitle); ?></h1>
    <form action="?<?php htmlout($action); ?>" method="post">
      
      <div>
        <label for="depature">Depature:</label>
        <select name="depature" id="depature">
          <option value="">Select one</option>
          <?php foreach ($flights as $flight): ?>
            <option value="<?php htmlout($flight['id']); ?>"<?php
                if ($flight['id'] == $flightid)
                {
                  echo ' selected';
                }
                ?>><?php htmlout($flight['depature']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <fieldset>
        <legend>Users:</legend>
        <?php foreach ($users as $user): ?>
          <div><label for="user<?php htmlout($user['id']);
              ?>"><input type="checkbox" name="users[]"
              id="user<?php htmlout($user['id']); ?>"
              value="<?php htmlout($user['id']); ?>"<?php
              if ($user['selected'])
              {
                echo ' checked';
              }
              ?>><?php htmlout($user['name']); ?></label></div>
        <?php endforeach; ?>
      </fieldset>
      <div>
        <input type="hidden" name="id" value="<?php
            htmlout($id); ?>">
        <input type="submit" value="<?php htmlout($button); ?>">
      </div>
    </form>
  </body>
</html>
