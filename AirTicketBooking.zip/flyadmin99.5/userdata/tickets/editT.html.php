<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php htmlout('Edit'); ?></title>
  </head>
  <body>
    <h1><?php htmlout('Edit'); ?></h1>
     
    <?php $buy = $_POST['buy'] ?>
    <?php $flightprice = $_POST['flightprice'] ?>
    <?php $ticketnumber = $_POST['ticketnumber'] ?>
    <?php $userid = $_POST['userid'] ?>

    <form action="index.php" method="post">

     您确定要买票吗？
             <input type="hidden" name="id" value="<?php
                  echo $_POST['id']; ?>">              
                

         <input type="hidden" name="userid" value="<?php
                  echo $_POST['userid']; ?>"> 
         <input type="hidden" name="flightprice" value="<?php
                  echo $_POST['flightprice']; ?>">   
         <input type="hidden" name="ticketnumber" value="<?php
                  echo $_POST['ticketnumber']; ?>">    
        <input type="hidden" name="buy" value="0">               
        <input type="submit" name="action" value="updateT">
      </div>
    </form>
  </body>
</html>
