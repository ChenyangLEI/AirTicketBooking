<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Tikcets</title>
  </head>
  <body>
    <h1>Manage Tikcets</h1>
    <h3>票数:<?php htmlout($ticketcount); ?></h3>

<table>
        <tr><th>Tickets Text</th></tr>
         <tr>
         <th align="left">ticketid</th>
         <th align="left">ticketnumber</th>
         <th align="left">price&nbsp&nbsp</th>
         <th align="left">flightid</th>
         </tr>
   <?php foreach ($tickets as $ticket): ?>
    <tr>
         
              <td><?php htmlout($ticket['id']); ?> &nbsp &nbsp </td>
              <td><?php htmlout($ticket['ticketnumber']-$ticket['flightid']*100); ?>
              &nbsp&nbsp</td>
              <td><?php htmlout($ticket['flightprice']); ?>&nbsp&nbsp</td>
              <td><?php htmlout($ticket['flightid']); ?>&nbsp&nbsp</td>
                     <form action="editT.html.php" method="post">
           <td> <div> <input type="hidden" name="id" value="<?php
              echo $ticket['id']; ?>">
              <input type="hidden" name="buy" value="<?php
              echo $ticket['buy']; ?>">
              <input type="hidden" name="flightprice" value="<?php
              echo $ticket['flightprice']; ?>">
              <input type="hidden" name="ticketnumber" value="<?php
              echo $ticket['ticketnumber']; ?>">
              <input type="hidden" name="userid" value="<?php
              echo $ticket['userid']; ?>">
              <input type="hidden" name="id" value="<?php
                  echo $ticket['id']; ?>">
              <input type="submit" name="action" value="editT">


            </div>
          </form>
          </td>
          </tr>
      <?php endforeach; ?>

    <p><a href="..">返回首页</a></p>
        <?php include '../logout.inc.html.php'; ?>
  </body>
</html>
