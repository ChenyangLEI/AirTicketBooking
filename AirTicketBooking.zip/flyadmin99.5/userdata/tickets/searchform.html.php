<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Tickets</title>
  </head>
  <body>
    <h1>Query Tickets</h1>

   
    <form action="" method="get">
      <p>View tickets satisfying the following criteria:</p>
      
      
        <div>
        <label for="depature">出发地 ：</label>
        <input type="text" name="depature" id="depature">    
      </div>
      <div>
        <label for="destination">目的地 ：</label>
        <input type="text" name="destination" id="destination">    
      </div>
      <div>
        <label for="flightdate">日期 ：</label>
        <input type="date" name="flightdate" id="flightdate">    
      </div>
      <div>
        <input type="hidden" name="action" value="search">

        <input type="submit" value="Search">
      </div>
    </form>
    <p><a href="..">返回上一页</a></p>
            <?php include '../logout.inc.html.php'; ?>

  </body>
</html>
