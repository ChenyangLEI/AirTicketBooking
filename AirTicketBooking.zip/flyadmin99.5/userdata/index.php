<?php
include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/magicquotes.inc.php';
require_once   '../access.inc.php';

$acc = '';

if (!userIsLoggedIn())
{
  include '../login.html.php';


  exit();
}


if (!userHasRole('auser'))
{
  $error = '太抱歉了，用户才能进来.';
  include '../accessdenied.html.php';
  exit();
}

  $accout = '';
  $userpassword = '';

if (isset($_GET['add']))
{
  $pageTitle = 'New User';
  $action = 'addform';
  $name =  '';
  $phone = '';
  $accout = '';
  $userpassword = '';

  $button = 'Add user';

  include 'adduser.html.php';
  exit();
}

if (isset($_GET['addform']))
{
  include 'db.inc.php';

  try
  {
    $sql = 'INSERT INTO user SET
          name = :name,
          phone = :phone,
          userpassword = :userpassword,
          accout = :accout';
    $s = $pdo->prepare($sql);
    $s->bindValue(':name', $_POST['name']);
    $s->bindValue(':phone', $_POST['phone']);
    $s->bindValue(':accout', $_POST['accout']);
    $s->bindValue(':userpassword', $_POST['userpassword']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error adding submitted user.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}

if (isset($_POST['action']) and $_POST['action'] == '编辑')
{
  include  'db.inc.php';

  try
  {
      $sql = 'SELECT id,name,accout,phone,userpassword FROM user WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching user details.';
    include 'error.html.php';
    exit();
  }

  $row = $s->fetch();

  $pageTitle = 'Edit User';
  $action = 'editform';
  $name = $row['name'];
  $phone = $row['phone'];
   $accout = $row['accout'];
  $userpassword = $row['userpassword'];
  $id = $row['id'];
  $button = 'Update user';
  include 'form.html.php';
  exit();
}

if (isset($_GET['editform']))
{
  include 'db.inc.php';

  try
  {
    $sql = 'UPDATE user SET
        name = :name,
        phone = :phone,
         userpassword = :userpassword,
         accout = :accout
    
        WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->bindValue(':name', $_POST['name']);
    $s->bindValue(':phone', $_POST['phone']);
    $s->bindValue(':accout', $_POST['accout']);
     $s->bindValue(':userpassword', $_POST['userpassword']);
  
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error updating submitted user.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}

if (isset($_POST['action']) and $_POST['action'] == '已购机票')
{
  include  'db.inc.php';

  try
  {
    $sql = 'SELECT ticket.id,ticket.ticketnumber,ticket.flightid,ticket.flightprice,ticket.userid,ticket.buy,flight.depature,flight.destination,flight.flightdate,flight.flighttime FROM ticket  INNER JOIN flight ON flight.id = ticket.flightid WHERE userid = :id AND  buy = 2 ' ;
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error getting list of tickets.';
    include 'error.html.php';
    exit();
  }

  $result = $s->fetchAll();
$ticketcount = 0;
$tickets[]= array('id' => '0',   
    'ticketnumber' => '0','flightid' => '0',
    'userid' => '0','buy' => '0',
    'depature' => '','destination' => '',
    'flightdate' => '','flighttime' =>'',
    'flightprice' => '0');
  foreach ($result as $row)
{$ticketcount = $ticketcount +1;
  $tickets[] = array('id' => $row['id'],   
    'ticketnumber' => $row['ticketnumber'],'flightid' => $row['flightid'],
    'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
    'userid' => $row['userid'],'buy' => $row['buy'],
    'flightprice' => $row['flightprice']);
}

include 'tickets.html.php';
exit();
}
if (isset($_POST['action']) and $_POST['action'] == '我的订单')
{
  include  'db.inc.php';

  try
  {
    $sql = 'SELECT ticket.id,ticket.ticketnumber,ticket.flightid,ticket.flightprice,ticket.userid,ticket.buy,flight.depature,flight.destination,flight.flightdate,flight.flighttime FROM ticket  INNER JOIN flight ON flight.id = ticket.flightid WHERE userid = :id AND (buy = 0 or buy = 3) ' ;
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error getting list of tickets.';
    include 'error.html.php';
    exit();
  }

  $result = $s->fetchAll();
$ticketcount = 0;
$tickets[]= array('id' => '0',   
    'ticketnumber' => '0','flightid' => '0',
    'userid' => '0','buy' => '0',
    'depature' => '','destination' => '',
    'flightdate' => '','flighttime' =>'',
    'flightprice' => '0');
  foreach ($result as $row)
{$ticketcount = $ticketcount +1;
  $tickets[] = array('id' => $row['id'],   
    'ticketnumber' => $row['ticketnumber'],'flightid' => $row['flightid'],
    'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
    'userid' => $row['userid'],'buy' => $row['buy'],
    'flightprice' => $row['flightprice']);
}

include 'tickets.html.php';
exit();
}

if (isset($_POST['action']) and $_POST['action'] == 'updateT')
{
  include 'db.inc.php';

  try
  {
    $sql = 'UPDATE ticket SET
        userid = :userid,
        buy = :buy,
        ticketnumber = :ticketnumber,
        flightprice = :flightprice
        WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->bindValue(':buy', $_POST['buy']);
    $s->bindValue(':ticketnumber', $_POST['ticketnumber']);
    $s->bindValue(':flightprice', $_POST['flightprice']);
    $s->bindValue(':userid', $_POST['userid']);
    $s->execute();

  }
  catch (PDOException $e)
  {
    $error = 'Error updating edit ticket.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}
// Display user list
include 'db.inc.php';
/*加一条语句限定一下修改方向*/
try
{
  $result = 'SELECT id,name,accout,phone,userpassword FROM user where accout 
    = :accout';
   $s = $pdo->prepare($result);
    $s->bindValue(':accout', $_SESSION['accout']);

    $s->execute();
}
catch (PDOException $e)
{
  $error = 'Error fetching users from the database!';
  include 'error.html.php';
  exit();
}

  $row = $s->fetch();

  $users[] = array('id' => $row['id'],   
    'name' => $row['name'],'accout' => $row['accout'],
    'phone' => $row['phone'],'userpassword' => $row['userpassword'],
  );
include 'users.html.php';
