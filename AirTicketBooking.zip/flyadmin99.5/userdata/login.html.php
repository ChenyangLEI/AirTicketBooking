<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Log In</title>
  </head>
  <body>
    <h1>Log In</h1>
    <p>这是一个需要登录才能看见的神秘页面 ヽ(ˋ▽ˊ)ノ</p>
    <?php if (isset($loginError)): ?>
      <p><?php htmlout($loginError); ?></p>
    <?php endif; ?>
    <form action="" method="post">
      <div>
        <label for="accout">账号: <input type="text" name="accout"
            id="accout"></label>
      </div>
      <div>
        <label for="userpassword">密码: <input type="password"
            name="userpassword" id="userpassword"></label>
      </div>
      <div>
        <input type="hidden" name="action" value="login">
        <input type="submit" value="Log in">
      </div>
    </form>
    <p><a href="/flyadmin99.5/">返回首页</a></p>
  </body>
</html>
