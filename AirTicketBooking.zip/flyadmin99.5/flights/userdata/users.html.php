<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Users</title>
  </head>
  <body>
    <h1>Manage Users</h1>
  
    <p><a href="?add">添加用户</a></p>
    <ul>
      <?php foreach ($users as $user): ?>
        <li>
          <form action="" method="post">
            <div>
                          <?php htmlout($user['id']); ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

              <?php htmlout($user['name']); ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
              <?php htmlout($user['accout']); ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
              <?php htmlout($user['phone']); ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
              <?php htmlout($user['userpassword']); ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
              <input type="hidden" name="id" value="<?php
                  echo $user['id']; ?>">
              <input type="submit" name="action" value="Edit">
              <input type="submit" name="action" value="Delete">
              <input type="submit" name="action" value="Tickets">
              <input type="submit" name="action" value="orders">

            </div>
          </form> 
        </li>
      <?php endforeach; ?>
    </ul>
    <p><a href="..">返回首页Return</a></p>
        <?php include '../logout.inc.html.php'; ?>

  </body>
</html>
