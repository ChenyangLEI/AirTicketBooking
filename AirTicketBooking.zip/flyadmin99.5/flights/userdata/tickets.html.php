<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Tikcets</title>
  </head>
  <body>
    <h1>Manage Tikcets</h1>

    <ul>
   <?php foreach ($tickets as $ticket): ?>
        <li>
          <form action="editT.html.php" method="post">
            <div>
              ticketid:<?php htmlout($ticket['id']); ?> &nbsp &nbsp 
              ticketnumber:<?php htmlout($ticket['ticketnumber']); ?>&nbsp&nbsp
              price:<?php htmlout($ticket['flightprice']); ?>&nbsp&nbsp
              flightid:<?php htmlout($ticket['flightid']); ?>&nbsp&nbsp
              userid:<?php htmlout($ticket['userid']); ?>&nbsp&nbsp
              buy:<?php htmlout($ticket['buy']); ?>&nbsp&nbsp
              <input type="hidden" name="id" value="<?php
                  echo $ticket['id']; ?>">
              <input type="submit" name="action" value="editT">


            </div>
          </form>
        </li>
      <?php endforeach; ?>

    </ul>
    <p><a href="..">返回首页Return</a></p>
        <?php include '../logout.inc.html.php'; ?>
  </body>
</html>
