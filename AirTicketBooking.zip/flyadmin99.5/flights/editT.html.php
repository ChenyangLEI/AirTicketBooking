<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php htmlout('Edit'); ?></title>
  </head>
  <body>
    <h1><?php htmlout('Edit'); ?></h1>
        <h3>buy:0待确认；1待售；2确认售出；3退票待确认</h3>

     
    <?php $buy = $_POST['buy'] ?>
    <?php $flightprice = $_POST['flightprice'] ?>
    <?php $ticketnumber = $_POST['ticketnumber'] ?>
    <?php $userid = $_POST['userid'] ?>

    <form action="index.php" method="post">

      <div>
        <label for="flightprice">flightprice: <input type="text" name="flightprice"
            id="flightprice" value="<?php htmlout($flightprice); ?>"></label>
      </div>

      <div>
        <label for="ticketnumber">ticketnumber: <input type="text" name="ticketnumber"
            id="ticketnumber" value="<?php htmlout($ticketnumber); ?>"></label>
      </div>

      <div>
        <label for="userid">USERID: <input type="text" name="userid"
            id="userid" value="<?php htmlout($userid); ?>"></label>
      </div>
      
            <div>
        <label for="buy">Buy: <input type="text" name="buy"
            id="buy" value="<?php htmlout($buy); ?>"></label>
      </div>

         <input type="hidden" name="id" value="<?php
                  echo $_POST['id']; ?>">                  
        <input type="submit" name="action" value="updateT">

      </div>
    </form>
  </body>
</html>
