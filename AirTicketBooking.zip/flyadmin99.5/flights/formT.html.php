<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php htmlout('Edit'); ?></title>
  </head>
  <body>
      <h1><?php htmlout('Edit'); ?></h1>

    <h2>flightid:<?php htmlout($_POST['id']); ?></h2>

    <form action="?addTT" method="post">
      <div>
        <label for="flightid">flightid: <input type="text" name="flightid"
            id="flightid" value="<?php
            htmlout($id); ?>"></label>
      </div>
      <div>
        <label for="flightprice">flightprice: <input type="text" name="flightprice"
            id="flightprice" value="<?php htmlout($price); ?>"></label>
      </div>
      <div>
        <label for="ticketnumber">ticketnumber: <input type="text" name="ticketnumber"
            id="ticketnumber" value=""></label>
      </div>
      <div>
        <label for="userid">USERID: <input type="text" name="userid"
            id="userid" value="0"></label>
      </div>
            <div>
        <label for="buy">Buy: <input type="text" name="buy"
            id="buy" value="1"></label>
      </div>


       
         <input type="hidden" name="id" value="<?php
                  echo $ticket['id']; ?>">
        <input type="submit" name="action" value="addTT">

      </div>
    </form>
  </body>
</html>
