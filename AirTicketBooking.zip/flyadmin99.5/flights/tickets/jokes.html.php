<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Ticket: Search Results</title>
  </head>
  <body>
    <h1>Search Results</h1>
    <?php if (isset($jokes)): ?>
      <table>
        <tr><th>Flight Text</th><th>Options</th></tr>
         <tr>
         <th align="left">出发地</th>
         <th align="left">目的地</th>
         <th align="left">日期</th>
         <th align="left">时间</th>
         <th align="left">票价</th>
         <th align="left">航班号</th>

         </tr>

        <?php foreach ($jokes as $flight): ?>
        
        <tr>
          <td><?php htmlout($flight['depature']); ?></td>
          <td><?php htmlout($flight['destination']); ?></td>
          <td><?php htmlout($flight['flightdate']); ?></td>
          <td><?php htmlout($flight['flighttime']); ?></td>
          <td><?php htmlout($flight['price']); ?></td>
          <td><?php htmlout($flight['id']); ?></td>

          <td>
            
            <form action="?" method="post">
              <div>
                <input type="hidden" name="id" value="<?php
                    htmlout($flight['id']); ?>">
                <input type="submit" name="action" value="Edit">
                <input type="submit" name="action" value="Delete">
                <input type="submit" name="action" value="addT">
              <input type="submit" name="action" value="Tickets">
              <input type="submit" name="action" value="orders">


              </div>
            </form>
          </td>
        </tr>
       

        <?php endforeach; ?>
      </table>
    <?php endif; ?>
    <p><a href="?">再搜一次</a></p>
    <p><a href="..">返回 </a></p>

  </body>
</html>
