<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Tikcets</title>
  </head>
  <body>
    <h1>Manage Tikcets</h1>
    票数:<?php htmlout($ticketcount); ?> &nbsp &nbsp 
<table>
        <tr><th>Tickets Text</th></tr>
         <tr>
         <th align="left">ticketid</th>
         <th align="left">ticketnumber</th>
         <th align="left">price&nbsp&nbsp</th>
         <th align="left">flightid</th>
         <th align="left">userid</th>
         <th align="left">buy</th>
         </tr>

            <?php foreach ($tickets as $ticket): ?>
<tr>
              <td><?php htmlout($ticket['id']); ?></td>
              <td><?php htmlout($ticket['ticketnumber']); ?></td>
             <td> <?php htmlout($ticket['flightprice']); ?></td>
             <td> <?php htmlout($ticket['flightid']); ?></td>
             <td> <?php htmlout($ticket['userid']); ?></td>
             <td> <?php htmlout($ticket['buy']); ?></td>

              <td> <form action="editT.html.php" method="post">
               <div>
              <input type="hidden" name="id" value="<?php
              echo $ticket['id']; ?>">
              <input type="hidden" name="buy" value="<?php
              echo $ticket['buy']; ?>">
              <input type="hidden" name="flightprice" value="<?php
              echo $ticket['flightprice']; ?>">
              <input type="hidden" name="ticketnumber" value="<?php
              echo $ticket['ticketnumber']; ?>">
              <input type="hidden" name="userid" value="<?php
              echo $ticket['userid']; ?>">

              <input type="submit" name="action" value="editT">


            </div>
          </form>
          </td>
          </tr>
       
      <?php endforeach; ?>
   </table>
    <p><a href="..">返回首页Return</a></p>
        <?php include '../logout.inc.html.php'; ?>
  </body>
</html>
