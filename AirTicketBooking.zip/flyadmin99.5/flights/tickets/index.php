<?php
include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/magicquotes.inc.php';

if (isset($_GET['add']))
{
  $pageTitle = 'New Ticket';
  $action = 'addform';
  $text = '';
  $flightid = '';
  $id = '';
  $button = 'Add ticket';

  include   'db.inc.php';

  // Build the list of authors
  try
  {
    $result = $pdo->query('SELECT id, depature, destination,flightdate,flighttime,
    price FROM flight');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of flights.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $flights[] = array('id' => $row['id'], 
      'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
  'price' => $row['price']);
  }

  // Build the list of users
try
  {
    $result = $pdo->query('SELECT id, name FROM user');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of users.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $users[] = array(
        'id' => $row['id'],
        'name' => $row['name'],
        'selected' => FALSE);
  }
 

  include 'form.html.php';
  exit();
}

if (isset($_GET['addform']))
{
  include  'db.inc.php';

  if ($_POST['depature'] == '')
  {
    $error = 'You must choose an depature for this tikcet.
        Click &lsquo;back&rsquo; and try again.';
    include 'error.html.php';
    exit();
  }
  
  try
  {
    $sql = 'INSERT INTO ticket SET          
        flightid = :flightid';
        ;
    $s = $pdo->prepare($sql);    
    $s->bindValue(':flightid', $_POST['depature']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error adding submitted ticket.';
    include 'error.html.php';
    exit();
  }

  $jokeid = $pdo->lastInsertId();

  if (isset($_POST['users']))
  {
    try
    {
      $sql = 'INSERT INTO ticketuser SET
          ticketid = :ticketid,
          userid = :userid';
      $s = $pdo->prepare($sql);

      foreach ($_POST['users'] as $userid)
      {
        $s->bindValue(':ticketid', $ticketid);
        $s->bindValue(':userid', $userid);
        $s->execute();
      }
    }
    catch (PDOException $e)
    {
      $error = 'Error inserting joke into selected users.';
      include 'error.html.php';
      exit();
    }
  }

  header('Location: .');
  exit();
}

if (isset($_POST['action']) and $_POST['action'] == 'Tickets')
{
  include  'db.inc.php';

  try
  {
    $sql = 'SELECT id,ticketnumber,flightid,flightprice,userid,buy FROM ticket WHERE flightid = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error getting list of tickets.';
    include 'error.html.php';
    exit();
  }

  $result = $s->fetchAll();
$ticketcount = 0;
$tickets[]= array('id' => '0',   
    'ticketnumber' => '0','flightid' => '0',
    'userid' => '0','buy' => '0',
    'flightprice' => '0');
  foreach ($result as $row)
{$ticketcount = $ticketcount +1;
  $tickets[] = array('id' => $row['id'],   
    'ticketnumber' => $row['ticketnumber'],'flightid' => $row['flightid'],
    'userid' => $row['userid'],'buy' => $row['buy'],
    'flightprice' => $row['flightprice']);
}
include 'tickets.html.php';
exit();
}

if (isset($_POST['action']) and $_POST['action'] == 'orders')
{
  include  'db.inc.php';

  try
  {
    $sql = 'SELECT id,ticketnumber,flightid,flightprice,userid,buy FROM ticket WHERE flightid = :id AND (buy = 0 or buy = 3)';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error getting list of tickets.';
    include 'error.html.php';
    exit();
  }

  $result = $s->fetchAll();
$ticketcount = 0;
$tickets[]= array('id' => '0',   
    'ticketnumber' => '0','flightid' => '0',
    'userid' => '0','buy' => '0',
    'flightprice' => '0');
  foreach ($result as $row)
{ $ticketcount = $ticketcount+1;
  $tickets[] = array('id' => $row['id'],   
    'ticketnumber' => $row['ticketnumber'],'flightid' => $row['flightid'],
    'userid' => $row['userid'],'buy' => $row['buy'],
    'flightprice' => $row['flightprice']);
}

include 'tickets.html.php';
exit();
}
if (isset($_POST['action']) and $_POST['action'] == 'Edit')
{
  include  'db.inc.php';

  try
  {
    $sql = 'SELECT id, depature, destination, flightdate, flighttime,price FROM flight WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching flight details.';
    include 'error.html.php';
    exit();
  }

  $row = $s->fetch();

  $pageTitle = 'Edit Flight';
  $action = 'editform';
  $depature = $row['depature'];
  $destination = $row['destination'];
  $flightdate = $row['flightdate'];
  $flighttime = $row['flighttime'];
  $price = $row['price'];
  $id = $row['id'];
  $button = 'Update flight';

  include 'form.html.php';
  exit();
}

if (isset($_GET['editform']))
{
  include 'db.inc.php';

  try
  {
    $sql = 'UPDATE flight SET
        depature = :depature,
        destination = :destination,
         flightdate = :flightdate,
        flighttime = :flighttime,
         price = :price
        WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->bindValue(':depature', $_POST['depature']);
    $s->bindValue(':destination', $_POST['destination']);
     $s->bindValue(':flightdate', $_POST['flightdate']);
    $s->bindValue(':flighttime', $_POST['flighttime']);
     $s->bindValue(':price', $_POST['price']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error updating submitted flight.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}


if (isset($_POST['action']) and $_POST['action'] == 'Delete')
{
  include  'db.inc.php';

  // Get jokes belonging to flight
  // 和飞机相关的票 
  /*    $sql = 'SELECT id FROM ticket WHERE flightid = :id';*/
  try
  {
    $sql = 'SELECT id FROM ticket WHERE flightid = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error getting list of flights to delete.';
    include 'error.html.php';
    exit();
  }

  $result = $s->fetchAll();

  // Delete joke category entries
  //ticketuser里删掉所有票
  /*   $sql = 'DELETE FROM ticketuser WHERE ticketid = :id';*/
  try
  {
    $sql = 'DELETE FROM ticketuser WHERE ticketid = :id';
    $s = $pdo->prepare($sql);

    // For each joke//ticket
      /*   $*/
    foreach ($result as $row)
    {
      $ticketid = $row['id'];
      $s->bindValue(':id', $ticketid);
      $s->execute();
    }
  }
  catch (PDOException $e)
  {
    $error = 'Error deleting user entries for flight.';
    include 'error.html.php';
    exit();
  }

  // Delete jokes belonging to flight
  //delete 票
  try
  {
    $sql = 'DELETE FROM ticket WHERE flightid = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error deleting tickets for flight.';
    include 'error.html.php';
    exit();
  }

  // Delete the flight
  try
  {
    $sql = 'DELETE FROM flight WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error deleting flight.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}
if (isset($_POST['action']) and $_POST['action'] == 'addT')
{
include  'db.inc.php';

  try
  {
    $sql = 'SELECT id, depature, destination, flightdate, flighttime,price FROM flight WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching flight details.';
    include 'error.html.php';
    exit();
  }

  $row = $s->fetch();

  $pageTitle = 'Edit Flight';
  $action = 'editform';
  $depature = $row['depature'];
  $destination = $row['destination'];
  $flightdate = $row['flightdate'];
  $flighttime = $row['flighttime'];
  $price = $row['price'];
  $id = $row['id'];
  $button = 'Update flight';
  include 'formT.html.php';
  exit();
}

if (isset($_GET['addTT']))
{
  include 'db.inc.php';

  try
  {
    $sql = 'INSERT INTO ticket SET
       
         flightid = :flightid,userid = :userid,buy = :buy,
        ticketnumber = :ticketnumber,
        flightprice = :flightprice';
    $s = $pdo->prepare($sql);
    $s->bindValue(':flightid', $_POST['flightid']);
        $s->bindValue(':userid', $_POST['userid']);
    $s->bindValue(':buy', $_POST['buy']);
     $s->bindValue(':flightprice', $_POST['flightprice']);
    $s->bindValue(':ticketnumber', $_POST['ticketnumber']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error adding submitted flight.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}


if (isset($_GET['action']) and $_GET['action'] == 'search')
{
  include  'db.inc.php';

  // The basic SELECT statement
  $select = 'SELECT id, depature,destination,flightdate,flighttime,price';
  $from   = ' FROM flight';
  $where  = ' WHERE TRUE';

  $placeholders = array();

//利用连接符来连接是关键；同时要将where $F
   if ($_GET['depature'] != '') // Some search text was specified
  {
    $where .= " AND depature LIKE :depature";
    $placeholders[':depature'] = '%' . $_GET['depature'] . '%';
  }
  if ($_GET['destination'] != '') // Some search text was specified
  {
    $where .= " AND destination LIKE :destination";
    $placeholders[':destination'] = '%' . $_GET['destination'] . '%';
  }
    if ($_GET['flightdate'] != '') // Some search text was specified
  {
    $where .= " AND flightdate LIKE :flightdate";
    $placeholders[':flightdate'] = '%' . $_GET['flightdate'] . '%';
  }


  try
  {
    $sql = $select . $from . $where;
    $s = $pdo->prepare($sql);
    $s->execute($placeholders);
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching jokes.';
    include 'error.html.php';
    exit();
  }

  foreach ($s as $row)
  {
    $jokes[] = array('id' => $row['id'], 
      'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
  'price' => $row['price']);
  }

  include 'jokes.html.php';
  exit();
}
if (isset($_POST['action']) and $_POST['action'] == 'updateT')
{
  include 'db.inc.php';

  try
  {
    $sql = 'UPDATE ticket SET
        userid = :userid,
        buy = :buy,
        ticketnumber = :ticketnumber,
        flightprice = :flightprice
        WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->bindValue(':buy', $_POST['buy']);
    $s->bindValue(':ticketnumber', $_POST['ticketnumber']);
    $s->bindValue(':flightprice', $_POST['flightprice']);
    $s->bindValue(':userid', $_POST['userid']);

    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error updating edit ticket.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}

// Display search form
include  'db.inc.php';

try
{
  $result = $pdo->query('SELECT id, depature,destination,flightdate,flighttime,price FROM flight');
}
catch (PDOException $e)
{
  $error = 'Error fetching authors from database!';
  include 'error.html.php';
  exit();
}

foreach ($result as $row)
{
  $authors[] = array('id' => $row['id'],   
    'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
  'price' => $row['price']);
}


try
{
  $result = $pdo->query('SELECT id, accout,name,phone FROM user');
}
catch (PDOException $e)
{
  $error = 'Error fetching categories from database!';
  include 'error.html.php';
  exit();
}

foreach ($result as $row)
{
  $categories[] = array('id' => $row['id'], 
    'name' => $row['name'],'accout' => $row['accout']);
} 

include 'searchform.html.php';
