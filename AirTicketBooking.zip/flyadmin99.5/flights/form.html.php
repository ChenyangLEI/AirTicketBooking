<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php htmlout($pageTitle); ?></title>
  </head>
  <body>
    <h1><?php htmlout($pageTitle); ?></h1>
    <form action="?<?php htmlout($action); ?>" method="post">
      <div>
        <label for="depature">出发地: <input type="text" name="depature"
            id="depature" value="<?php htmlout($depature); ?>"></label>
      </div>
      <div>
        <label for="destination">目的地: <input type="text" name="destination"
            id="destinationdestination" value="<?php htmlout($destination); ?>"></label>
      </div>
       <div>
        <label for="flightdate">日期: <input type="text" name="flightdate"
            id="flightdate" value="<?php htmlout($flightdate); ?>"></label>
      </div>
       <div>
        <label for="flighttime">时间 : <input type="text" name="flighttime"
            id="flighttime" value="<?php htmlout($flighttime); ?>"></label>
      </div>
       <div>
        <label for="price">价格 : <input type="text" name="price"
            id="price" value="<?php htmlout($price); ?>"></label>
      </div>
      <div>
        <input type="hidden" name="id" value="<?php
            htmlout($id); ?>">
        <input type="submit" value="<?php htmlout($button); ?>">
      </div>
    </form>
  </body>
</html>
