<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Flights</title>
  </head>
  <body>
    <h1>Manage Flights</h1>
     <li><a href="tickets/">查询航班</a></li>
     <li><a href="userdata/">用户管理</a></li>
     <li><a href="?add">添加航班</a></li>

<p><table>
        <tr><th>所有航班</th></tr>
         <tr>
         <th align="left">航班号</th>
         <th align="left">出发地</th>
         <th align="left">目的地&nbsp&nbsp</th>
         <th align="left">日期</th>
         <th align="left">时间</th>
         <th align="left">价格</th>
         </tr>

      <?php foreach ($flights as $flight): ?>
        
        <tr>
        
         
             <td> <?php htmlout($flight['id']); ?></td>
              <td><?php htmlout($flight['depature']); ?></td>
             <td> <?php htmlout($flight['destination']); ?></td>
             <td> <?php htmlout($flight['flightdate']); ?></td>
            <td>  <?php htmlout($flight['flighttime']); ?> </td>
            <td>  <?php htmlout($flight['price']); ?> </td>
            
            <td>
            <form action="" method="post">
            <div>
            
            <td>  <input type="hidden" name="id" value="<?php
                  echo $flight['id']; ?>">
             <input type="submit" name="action" value="Edit"></td>
               <td> <input type="submit" name="action" value="Delete"></td>
            <td>  <input type="submit" name="action" value="Tickets"></td>
              <td><input type="submit" name="action" value="addT"></td>
             <td> <input type="submit" name="action" value="orders"></td>



            </div>
          </form>
          </td>
          </tr>
      
      <?php endforeach; ?>
    

      </table>
    </p>

    <p><a href="..">返回首页</a></p>
        <?php include '../logout.inc.html.php'; ?>
  </body>
</html>
