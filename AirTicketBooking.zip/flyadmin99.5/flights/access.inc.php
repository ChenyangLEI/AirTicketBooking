<?php

function userIsLoggedIn()
{
  if (isset($_POST['action']) and $_POST['action'] == 'login')
  {
    if (!isset($_POST['accout']) or $_POST['accout'] == '' or
      !isset($_POST['userpassword']) or $_POST['userpassword'] == '')
    {
      $GLOBALS['loginError'] = 'Please fill in both fields';
      return FALSE;
    }



    if (databaseContainsUser($_POST['accout'], $_POST['userpassword']))
    {
      session_start();
      $_SESSION['loggedIn'] = TRUE;
      $_SESSION['accout'] = $_POST['accout'];
      $_SESSION['userpassword'] = $_POST['userpassword'];
      return TRUE;
    }
    else
    {
      session_start();
      unset($_SESSION['loggedIn']);
      unset($_SESSION['accout']);
      unset($_SESSION['userpassword']);
      $GLOBALS['loginError'] =
          'The specified accout address or userpassword was incorrect.';
      return FALSE;
    }
  }

  if (isset($_POST['action']) and $_POST['action'] == 'logout')
  {
    session_start();
    unset($_SESSION['loggedIn']);
    unset($_SESSION['accout']);
    unset($_SESSION['userpassword']);
    header('Location: ' . $_POST['goto']);
    exit();
  }

  session_start();
  if (isset($_SESSION['loggedIn']))
  {
    return databaseContainsUser($_SESSION['accout'], $_SESSION['userpassword']);
  }
}

function databaseContainsUser($accout, $userpassword)
{
  include 'db.inc.php';

  try
  {
    $sql = 'SELECT COUNT(*) FROM user
        WHERE accout = :accout AND userpassword = :userpassword';
    $s = $pdo->prepare($sql);
    $s->bindValue(':accout', $accout);
    $s->bindValue(':userpassword', $userpassword);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error searching for user.';
    include 'error.html.php';
    exit();
  }

  $row = $s->fetch();

  if ($row[0] > 0)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}

function userHasRole($role)
{
  include 'db.inc.php';

  try
  {
    $sql = "SELECT COUNT(*) FROM user
        INNER JOIN userrole ON user.id = userid
        INNER JOIN role ON roleid = role.id
        WHERE accout = :accout AND role.id = :roleId";
    $s = $pdo->prepare($sql);
    $s->bindValue(':accout', $_SESSION['accout']);
    $s->bindValue(':roleId', $role);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error searching for user roles.';
    include 'error.html.php';
    exit();
  }

  $row = $s->fetch();

  if ($row[0] > 0)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}
