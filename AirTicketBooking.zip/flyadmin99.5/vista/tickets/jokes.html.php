<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Manage Jokes: Search Results</title>
  </head>
  <body>
    <h1>Search Results</h1>
    <?php if (isset($jokes)): ?>
      <table>
        <tr><th>Joke Text</th><th>Options</th></tr>
        <?php foreach ($jokes as $joke): ?>
        <tr>
          <td><?php htmlout($joke['depature']); ?></td>
                <td><?php htmlout($joke['destination']); ?></td>
                      <td><?php htmlout($joke['flightdate']); ?></td>
                            <td><?php htmlout($joke['flighttime']); ?></td>
                                  <td><?php htmlout('￥'.$joke['price']); ?></td>
          <td> <td><?php htmlout('您需要成为用户才能购买'); ?></td>
          <td>
            </td>
        </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
    <p><a href="?">New search</a></p>
    <p><a href="..">回到可以注册成为用户的地方</a></p>
  </body>
</html>
