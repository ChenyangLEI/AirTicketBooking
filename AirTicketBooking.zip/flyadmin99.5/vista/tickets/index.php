<?php
include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/magicquotes.inc.php';

if (isset($_GET['add']))
{
  $pageTitle = 'New Ticket';
  $action = 'addform';
  $text = '';
  $flightid = '';
  $id = '';
  $button = 'Add ticket';

  include   'db.inc.php';

  // Build the list of authors
  try
  {
    $result = $pdo->query('SELECT id, depature, destination,flightdate,flighttime,
    price FROM flight');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of flights.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $flights[] = array('id' => $row['id'], 
      'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
  'price' => $row['price']);
  }

  // Build the list of users
try
  {
    $result = $pdo->query('SELECT id, name FROM user');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of users.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $users[] = array(
        'id' => $row['id'],
        'name' => $row['name'],
        'selected' => FALSE);
  }
 

  include 'form.html.php';
  exit();
}

if (isset($_GET['addform']))
{
  include  'db.inc.php';

  if ($_POST['depature'] == '')
  {
    $error = 'You must choose an depature for this tikcet.
        Click &lsquo;back&rsquo; and try again.';
    include 'error.html.php';
    exit();
  }
  
  try
  {
    $sql = 'INSERT INTO ticket SET          
        flightid = :flightid';
        ;
    $s = $pdo->prepare($sql);    
    $s->bindValue(':flightid', $_POST['depature']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error adding submitted ticket.';
    include 'error.html.php';
    exit();
  }

  $jokeid = $pdo->lastInsertId();

  if (isset($_POST['users']))
  {
    try
    {
      $sql = 'INSERT INTO ticketuser SET
          ticketid = :ticketid,
          userid = :userid';
      $s = $pdo->prepare($sql);

      foreach ($_POST['users'] as $userid)
      {
        $s->bindValue(':ticketid', $ticketid);
        $s->bindValue(':userid', $userid);
        $s->execute();
      }
    }
    catch (PDOException $e)
    {
      $error = 'Error inserting joke into selected users.';
      include 'error.html.php';
      exit();
    }
  }

  header('Location: .');
  exit();
}

if (isset($_POST['action']) and $_POST['action'] == 'Edit')
{
  include $_SERVER['DOCUMENT_ROOT'] . '/includes/db.inc.php';

  try
  {
    $sql = 'SELECT id, joketext, authorid FROM joke WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching joke details.';
    include 'error.html.php';
    exit();
  }
  $row = $s->fetch();

  $pageTitle = 'Edit Joke';
  $action = 'editform';
  $text = $row['joketext'];
  $authorid = $row['authorid'];
  $id = $row['id'];
  $button = 'Update joke';

  // Build the list of authors
  try
  {
    $result = $pdo->query('SELECT id, name FROM author');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of authors.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $authors[] = array('id' => $row['id'], 'name' => $row['name']);
  }

  // Get list of categories containing this joke
  try
  {
    $sql = 'SELECT categoryid FROM jokecategory WHERE jokeid = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $id);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of selected categories.';
    include 'error.html.php';
    exit();
  }

  foreach ($s as $row)
  {
    $selectedCategories[] = $row['categoryid'];
  }

  // Build the list of all categories
  try
  {
    $result = $pdo->query('SELECT id, name FROM category');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of categories.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $categories[] = array(
        'id' => $row['id'],
        'name' => $row['name'],
        'selected' => in_array($row['id'], $selectedCategories));
  }

  include 'form.html.php';
  exit();
}

if (isset($_GET['editform']))
{
  include $_SERVER['DOCUMENT_ROOT'] . '/includes/db.inc.php';

  if ($_POST['author'] == '')
  {
    $error = 'You must choose an author for this joke.
        Click &lsquo;back&rsquo; and try again.';
    include 'error.html.php';
    exit();
  }

  try
  {
    $sql = 'UPDATE joke SET
        joketext = :joketext,
        authorid = :authorid
        WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->bindValue(':joketext', $_POST['text']);
    $s->bindValue(':authorid', $_POST['author']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error updating submitted joke.';
    include 'error.html.php';
    exit();
  }

  try
  {
    $sql = 'DELETE FROM jokecategory WHERE jokeid = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error removing obsolete joke category entries.';
    include 'error.html.php';
    exit();
  }

  if (isset($_POST['categories']))
  {
    try
    {
      $sql = 'INSERT INTO jokecategory SET
          jokeid = :jokeid,
          categoryid = :categoryid';
      $s = $pdo->prepare($sql);

      foreach ($_POST['categories'] as $categoryid)
      {
        $s->bindValue(':jokeid', $_POST['id']);
        $s->bindValue(':categoryid', $categoryid);
        $s->execute();
      }
    }
    catch (PDOException $e)
    {
      $error = 'Error inserting joke into selected categories.';
      include 'error.html.php';
      exit();
    }
  }

  header('Location: .');
  exit();
}

if (isset($_POST['action']) and $_POST['action'] == 'Delete')
{
  include $_SERVER['DOCUMENT_ROOT'] . '/includes/db.inc.php';

  // Delete category assignments for this joke
  try
  {
    $sql = 'DELETE FROM jokecategory WHERE jokeid = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error removing joke from categories.';
    include 'error.html.php';
    exit();
  }

  // Delete the joke
  try
  {
    $sql = 'DELETE FROM joke WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error deleting joke.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}

if (isset($_GET['action']) and $_GET['action'] == 'search')
{
  include  'db.inc.php';

  // The basic SELECT statement
  $select = 'SELECT id, depature,destination,flightdate,flighttime,price';
  $from   = ' FROM flight';
  $where  = ' WHERE TRUE';

  $placeholders = array();




   if ($_GET['depature'] != '') // Some search text was specified
  {
    $where .= " AND depature LIKE :depature";
    $placeholders[':depature'] = '%' . $_GET['depature'] . '%';
  }
  if ($_GET['destination'] != '') // Some search text was specified
  {
    $where .= " AND destination LIKE :destination";
    $placeholders[':destination'] = '%' . $_GET['destination'] . '%';
  }
    if ($_GET['flightdate'] != '') // Some search text was specified
  {
    $where .= " AND flightdate LIKE :flightdate";
    $placeholders[':flightdate'] = '%' . $_GET['flightdate'] . '%';
  }

  try
  {
    $sql = $select . $from . $where;
    $s = $pdo->prepare($sql);
    $s->execute($placeholders);
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching jokes.';
    include 'error.html.php';
    exit();
  }

  foreach ($s as $row)
  {
    $jokes[] = array('id' => $row['id'], 
      'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
  'price' => $row['price']);
  }

  include 'jokes.html.php';
  exit();
}

// Display search form
include  'db.inc.php';

try
{
  $result = $pdo->query('SELECT id, depature,destination,flightdate,flighttime,price FROM flight');
}
catch (PDOException $e)
{
  $error = 'Error fetching authors from database!';
  include 'error.html.php';
  exit();
}

foreach ($result as $row)
{
  $authors[] = array('id' => $row['id'],   
    'depature' => $row['depature'],'destination' => $row['destination'],
    'flightdate' => $row['flightdate'],'flighttime' => $row['flighttime'],
  'price' => $row['price']);
}


try
{
  $result = $pdo->query('SELECT id, accout,name,phone FROM user');
}
catch (PDOException $e)
{
  $error = 'Error fetching categories from database!';
  include 'error.html.php';
  exit();
}

foreach ($result as $row)
{
  $categories[] = array('id' => $row['id'], 
    'name' => $row['name'],'accout' => $row['accout']);
} 

include 'searchform.html.php';
