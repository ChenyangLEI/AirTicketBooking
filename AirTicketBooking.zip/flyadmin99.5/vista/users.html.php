<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>游客</title>
  </head>
  <body>
    <h1>游客</h1>
     <li><a href="tickets/">航班查询</a></li>
    <p><a href="?add">注册</a></p>


    <p><a href="..">返回首页Return</a></p>
  </body>
</html>
