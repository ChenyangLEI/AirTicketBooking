<?php
include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/magicquotes.inc.php';

  $accout = '';
  $userpassword = '';

if (isset($_GET['add']))
{include 'db.inc.php';
  $pageTitle = 'New User';
  $action = 'addform';
  $name =  '';
  $phone = '';
  $accout = '';
  $userpassword = '';

  $button = 'Add user';

// Build the list of roles
  try
  {
    $result = $pdo->query('SELECT id, description FROM role');
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching list of roles.';
    include 'error.html.php';
    exit();
  }

  foreach ($result as $row)
  {
    $roles[] = array(
      'id' => $row['id'],
      'description' => $row['description'],
      'selected' => FALSE);
  }

  include 'adduser.html.php';
  exit();
}

if (isset($_GET['addform']))
{
  include 'db.inc.php';

if($_POST['userpassword1'] == $_POST['userpassword'])

{  try
  {
    $sql = 'INSERT INTO user SET
          name = :name,
          phone = :phone,
          userpassword = :userpassword,
          accout = :accout';
    $s = $pdo->prepare($sql);
    $s->bindValue(':name', $_POST['name']);
    $s->bindValue(':phone', $_POST['phone']);
    $s->bindValue(':accout', $_POST['accout']);
    $s->bindValue(':userpassword', $_POST['userpassword']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error adding submitted user.';
    include 'error.html.php';
    exit();
  }
 $userid = $pdo->lastInsertId();


  if (isset($_POST['roles']))
  {
    foreach ($_POST['roles'] as $role)
    {
      try
      {
        $sql = 'INSERT INTO userrole SET
            userid = :userid,
            roleid = :roleid';
        $s = $pdo->prepare($sql);
        $s->bindValue(':userid', $userid);
        $s->bindValue(':roleid', $role);
        $s->execute();
      }
      catch (PDOException $e)
      {
        $error = 'Error assigning selected role to user.';
        include 'error.html.php';
        exit();
      }
    }
  }




  header('Location: .');
  exit();}


else{$error = 'Check your password and account.';
    include 'error.html.php';
  exit();
}

}


if (isset($_POST['action']) and $_POST['action'] == 'Edit')
{
  include  'db.inc.php';

  try
  {
      $result = $pdo->query('SELECT id,name,accout,phone,userpassword FROM user WHERE id = :id');
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error fetching user details.';
    include 'error.html.php';
    exit();
  }

  $row = $s->fetch();

  $pageTitle = 'Edit User';
  $action = 'editform';
  $name = $row['name'];
  $phone = $row['phone'];
   $accout = $row['accout'];
  $userpassword = $row['userpassword'];
  $id = $row['id'];
  $button = 'Update user';
  include 'form.html.php';
  exit();
}

if (isset($_GET['editform']))
{
  include 'db.inc.php';

  try
  {
    $sql = 'UPDATE user SET
        name = :name,
        phone = :phone,
         userpassword = :userpassword,
         accout = :accout
        WHERE id = :id';
    $s = $pdo->prepare($sql);
    $s->bindValue(':id', $_POST['id']);
    $s->bindValue(':name', $_POST['name']);
    $s->bindValue(':phone', $_POST['phone']);
    $s->bindValue(':accout', $_POST['accout']);
     $s->bindValue(':userpassword', $_POST['userpassword']);
  
    $s->execute();
  }
  catch (PDOException $e)
  {
    $error = 'Error updating submitted user.';
    include 'error.html.php';
    exit();
  }

  header('Location: .');
  exit();
}


// Display user list
include 'db.inc.php';

try
{
  $result = $pdo->query('SELECT id,name,accout,phone,userpassword FROM user');
}
catch (PDOException $e)
{
  $error = 'Error fetching users from the database!';
  include 'error.html.php';
  exit();
}

foreach ($result as $row)
{
  $users[] = array('id' => $row['id'],   
    'name' => $row['name'],'accout' => $row['accout'],
    'phone' => $row['phone'],'userpassword' => $row['userpassword'],
  );
}

include 'users.html.php';
