<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Access Denied</title>
  </head>
  <body>
    <h1>⊙﹏⊙∥∣° 失败了</h1>
    <p><?php htmlout($error); ?></p>
  </body>
</html>
